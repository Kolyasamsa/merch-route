import calendar
from datetime import date
from io import BytesIO

import pandas as pd
import streamlit as st

from routes import get_workers
from database import get_completed_visits_for_period
from utils import MONTHS


def show_timesheet(df):
    st.subheader("📊 Табель прохождений")

    today = date.today()
    col_year, col_month = st.columns(2)

    with col_year:
        year_options = [today.year - 1, today.year, today.year + 1]
        year = st.selectbox(
            "📅 Год",
            year_options,
            index=1,
            key="timesheet_year",
        )

    with col_month:
        month_name = st.selectbox(
            "📅 Месяц",
            MONTHS,
            index=today.month - 1,
            key="timesheet_month",
        )

    month = MONTHS.index(month_name) + 1
    days_in_month = calendar.monthrange(year, month)[1]
    start_date = date(year, month, 1).isoformat()
    end_date = date(year, month, days_in_month).isoformat()

    try:
        visits = get_completed_visits_for_period(start_date, end_date)
    except Exception as error:
        st.error(f"Ошибка загрузки табеля: {error}")
        return

    visit_counts = {}
    for visit in visits:
        key = (visit["worker"], visit["visit_date"])
        visit_counts[key] = visit_counts.get(key, 0) + 1

    table_data = []
    for worker in get_workers(df):
        row = {"Мерчендайзер": worker}
        total = 0

        for day_number in range(1, days_in_month + 1):
            current_date = date(year, month, day_number).isoformat()
            completed_count = visit_counts.get((worker, current_date), 0)
            row[f"{day_number:02d}.{month_name[:3]}"] = completed_count
            total += completed_count

        row["Итого"] = total
        table_data.append(row)

    timesheet_df = pd.DataFrame(table_data)
    st.dataframe(timesheet_df, use_container_width=True, hide_index=True)

    excel_buffer = BytesIO()
    with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
        timesheet_df.to_excel(writer, index=False, sheet_name="Табель")

    st.download_button(
        label="⬇️ Скачать табель Excel",
        data=excel_buffer.getvalue(),
        file_name=f"Табель_{month_name}_{year}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )
