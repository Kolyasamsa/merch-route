from datetime import date

import streamlit as st

from config import DAYS
from routes import get_workers, get_worker_data, get_available_days, get_routes_for_day
from database import get_completed_visits, get_visit_photos, get_visit_comments, create_visit_comment
from utils import MONTHS, get_point_key, get_dates_for_weekday, get_default_date
from ui.photos import render_photo_grid
from ui.timesheet import show_timesheet


def _render_filters(worker_data):
    today = date.today()
    available_days = get_available_days(worker_data)
    if not available_days:
        st.error("Для выбранного мерчендайзера не настроены дни маршрутов.")
        return None

    default_day = DAYS[today.weekday()]
    day_index = available_days.index(default_day) if default_day in available_days else 0
    day = st.selectbox("📅 День маршрута", available_days, index=day_index, key="supervisor_day")

    year_options = [today.year - 1, today.year, today.year + 1]
    year = st.selectbox("📅 Год", year_options, index=1, key="supervisor_year")
    month_name = st.selectbox("📅 Месяц", MONTHS, index=today.month - 1, key="supervisor_month")
    month = MONTHS.index(month_name) + 1

    available_dates = get_dates_for_weekday(year, month, day)
    if not available_dates:
        st.error("Для выбранного месяца нет дат этого дня недели.")
        return None

    default_date = get_default_date(available_dates)
    selected_date = st.selectbox(
        "📆 Дата маршрута",
        available_dates,
        index=available_dates.index(default_date),
        format_func=lambda value: value.strftime("%d.%m.%Y"),
        key="supervisor_date",
    )

    return day, selected_date, get_routes_for_day(worker_data, day)


def _render_comments(visit, supervisor):
    st.divider()
    st.subheader("💬 Обсуждение ТТ")

    try:
        comments = get_visit_comments(visit["id"])
        if comments:
            for item in comments:
                role_text = "👩‍💼 Супервайзер" if item.get("author_role") == "supervisor" else "👤 Мерчендайзер"
                st.markdown(f"**{role_text}: {item.get('author', 'Неизвестно')}**")
                st.write(item.get("comment", ""))
                if item.get("created_at"):
                    st.caption(f"🕒 {item['created_at']}")
                st.divider()
        else:
            st.caption("Комментариев пока нет.")

        new_comment = st.text_area(
            "Написать комментарий",
            placeholder="Например: торты нужно было переставить на уровень глаз...",
            key=f"supervisor_comment_{visit['id']}",
        )
        if st.button(
            "💬 Отправить комментарий",
            key=f"send_supervisor_comment_{visit['id']}",
            type="primary",
            use_container_width=True,
        ):
            if not new_comment.strip():
                st.warning("Введите комментарий.")
                return
            create_visit_comment(visit["id"], supervisor, "supervisor", new_comment)
            st.rerun()
    except Exception as error:
        st.warning(f"Не удалось загрузить комментарии: {error}")


def _render_completed_visit(visit, supervisor):
    st.success("🟢 ТТ пройдена")
    if visit.get("completed_at"):
        st.write(f"🕒 **Время:** {visit['completed_at']}")

    st.divider()
    st.write("💬 **Комментарий мерчендайзера:**")
    comment = visit.get("comment", "")
    st.write(comment) if comment else st.caption("Комментарий отсутствует")

    st.divider()
    try:
        photos = get_visit_photos(visit["id"])
        if photos:
            st.write("📷 **Фотографии:**")
            render_photo_grid(photos, f"supervisor_{visit['id']}")
        else:
            st.info("Фотографии отсутствуют.")
    except Exception as error:
        st.warning(f"Не удалось загрузить фотографии: {error}")

    _render_comments(visit, supervisor)


def show_supervisor_dashboard(df, supervisor, logout):
    col_title, col_logout = st.columns([4, 1])
    with col_title:
        st.title("👩‍💼 Панель супервайзера")
        st.caption(f"👤 Супервайзер: {supervisor}")
    with col_logout:
        st.write("")
        if st.button("🚪 Выйти", use_container_width=True):
            logout()

    tab_routes, tab_timesheet = st.tabs(["📍 Просмотр маршрутов", "📊 Табель"])

    with tab_routes:
        workers = get_workers(df)
        selected_worker = st.selectbox("👤 Мерчендайзер", workers, key="supervisor_worker")
        worker_data = get_worker_data(df, selected_worker)
        filters = _render_filters(worker_data)
        if filters is None:
            return

        day, selected_date, (day_data, routes) = filters
        try:
            visits = get_completed_visits(selected_date.isoformat(), selected_worker)
        except Exception as error:
            st.error(f"Ошибка загрузки прохождений: {error}")
            visits = []

        completed_visits = {
            get_point_key(
                visit["worker"], visit["weekday"], visit["route"], visit["shop"], visit["address"]
            ): visit
            for visit in visits
        }

        st.divider()
        st.subheader(f"👤 {selected_worker}")
        st.write(f"📅 **{day}, {selected_date:%d.%m.%Y}**")

        total_points = len(day_data)
        completed_points = sum(
            get_point_key(selected_worker, day, point["Маршрут"], point["Магазин"], point["Адрес"]) in completed_visits
            for _, point in day_data.iterrows()
        )

        col1, col2, col3 = st.columns(3)
        col1.metric("Всего ТТ", total_points)
        col2.metric("Пройдено", completed_points)
        col3.metric("Осталось", total_points - completed_points)
        st.progress(completed_points / total_points if total_points else 0)

        for route in routes:
            route_data = day_data[day_data["Маршрут"] == route]
            total_route_points = len(route_data)
            completed_route_points = sum(
                get_point_key(selected_worker, day, route, point["Магазин"], point["Адрес"]) in completed_visits
                for _, point in route_data.iterrows()
            )

            st.divider()
            st.subheader(f"🚗 {route}")
            st.progress(completed_route_points / total_route_points if total_route_points else 0)
            st.caption(f"Пройдено: {completed_route_points} / {total_route_points}")

            for number, (_, point) in enumerate(route_data.iterrows(), start=1):
                shop = point["Магазин"]
                address = point["Адрес"]
                point_key = get_point_key(selected_worker, day, route, shop, address)
                visit = completed_visits.get(point_key)
                status = "🟢" if visit else "🔴"
                status_text = "Пройдена" if visit else "Не пройдена"

                with st.expander(f"{status} {number}. {shop} — {address} ({status_text})"):
                    st.write(f"🏪 **Магазин:** {shop}")
                    st.write(f"📍 **Адрес:** {address}")
                    if visit is None:
                        st.error("🔴 ТТ не пройдена")
                    else:
                        _render_completed_visit(visit, supervisor)

    with tab_timesheet:
        show_timesheet(df)
