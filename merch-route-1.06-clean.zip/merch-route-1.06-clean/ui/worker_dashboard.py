from datetime import date

import streamlit as st

from config import DAYS
from routes import get_worker_data, get_available_days, get_routes_for_day
from database import (
    get_completed_visits,
    get_visit_photos,
    create_visit,
    upload_visit_photos,
    replace_visit_photos,
    update_visit_comment,
    clear_database_cache,
)
from utils import MONTHS, get_point_key, get_dates_for_weekday, get_default_date
from ui.photos import render_photo_grid


PHOTO_TYPES = ["jpg", "jpeg", "png"]


def _render_route_filters(worker_data):
    today = date.today()
    available_days = get_available_days(worker_data)

    if not available_days:
        st.error("Для мерчендайзера не настроены дни маршрутов.")
        return None

    default_day = DAYS[today.weekday()]
    day_index = available_days.index(default_day) if default_day in available_days else 0
    day = st.selectbox("📅 День маршрута", available_days, index=day_index)

    year_options = [today.year - 1, today.year, today.year + 1]
    year = st.selectbox("📅 Год", year_options, index=1)

    month_name = st.selectbox("📅 Месяц", MONTHS, index=today.month - 1)
    month = MONTHS.index(month_name) + 1
    available_dates = get_dates_for_weekday(year, month, day)

    if not available_dates:
        st.error("Для выбранного месяца нет дат этого дня недели.")
        return None

    default_date = get_default_date(available_dates)
    selected_date = st.selectbox(
        "📆 Дата маршрута",
        available_dates,
        index=available_dates.index(default_date),
        format_func=lambda value: value.strftime("%d.%m.%Y"),
    )

    return day, selected_date, get_routes_for_day(worker_data, day)


def _render_new_visit(point_key, selected_date, worker, day, route, shop, address):
    photos = st.file_uploader(
        "📷 Добавить фотографии",
        type=PHOTO_TYPES,
        accept_multiple_files=True,
        key=f"photos_{point_key}",
    )
    comment = st.text_area(
        "💬 Комментарий",
        placeholder="Например: товара нет, малый остаток, причина отсутствия...",
        key=f"comment_{point_key}",
    )

    if not st.button(
        "✓ ЗАВЕРШИТЬ ТТ",
        key=f"complete_{point_key}",
        type="primary",
        use_container_width=True,
    ):
        return

    if not photos:
        st.warning("📷 Добавьте хотя бы одну фотографию перед завершением ТТ.")
        return

    try:
        visit = create_visit(
            selected_date.isoformat(), worker, day, route, shop, address, comment
        )
        upload_visit_photos(photos, visit["id"])
        clear_database_cache()
        st.rerun()
    except Exception as error:
        st.error(f"Ошибка сохранения: {error}")


def _render_photo_section(visit):
    st.divider()
    st.write("📷 **Фотографии**")

    state_key = f"photo_edit_mode_{visit['id']}"
    st.session_state.setdefault(state_key, False)

    try:
        saved_photos = get_visit_photos(visit["id"])
    except Exception as error:
        st.warning(f"Не удалось загрузить фотографии: {error}")
        return

    if not st.session_state[state_key]:
        if saved_photos:
            render_photo_grid(saved_photos, f"worker_{visit['id']}")
        else:
            st.info("К этой ТТ нет фотографий.")

        if st.button(
            "✏️ Заменить фотографии",
            key=f"edit_photos_{visit['id']}",
            use_container_width=True,
        ):
            st.session_state[state_key] = True
            st.rerun()
        return

    st.write("✏️ **Замена фотографий**")
    if saved_photos:
        st.caption("Текущие фотографии:")
        render_photo_grid(saved_photos, f"worker_{visit['id']}")

    new_photos = st.file_uploader(
        "📷 Выберите новые фотографии",
        type=PHOTO_TYPES,
        accept_multiple_files=True,
        key=f"replace_photos_{visit['id']}",
    )

    col_replace, col_cancel = st.columns(2)
    with col_replace:
        if st.button(
            "💾 Заменить",
            key=f"save_photos_{visit['id']}",
            use_container_width=True,
        ):
            if not new_photos:
                st.warning("Выберите хотя бы одну фотографию.")
                return
            try:
                replace_visit_photos(new_photos, visit["id"])
                st.session_state[state_key] = False
                st.rerun()
            except Exception as error:
                st.error(f"Ошибка замены фотографий: {error}")

    with col_cancel:
        if st.button(
            "✖ Отмена",
            key=f"cancel_photos_{visit['id']}",
            use_container_width=True,
        ):
            st.session_state[state_key] = False
            st.rerun()


def _render_comment_section(visit):
    st.divider()
    st.write("📝 **Комментарий мерчендайзера**")

    state_key = f"edit_mode_{visit['id']}"
    st.session_state.setdefault(state_key, False)

    if not st.session_state[state_key]:
        saved_comment = visit.get("comment", "")
        if saved_comment:
            st.write(saved_comment)
        else:
            st.caption("Комментарий отсутствует")

        if st.button(
            "✏️ Редактировать комментарий",
            key=f"edit_button_{visit['id']}",
            use_container_width=True,
        ):
            st.session_state[state_key] = True
            st.rerun()
        return

    edited_comment = st.text_area(
        "Комментарий к ТТ",
        value=visit.get("comment", ""),
        key=f"edit_comment_{visit['id']}",
    )
    col_save, col_cancel = st.columns(2)

    with col_save:
        if st.button(
            "💾 Сохранить",
            key=f"save_comment_{visit['id']}",
            use_container_width=True,
        ):
            try:
                update_visit_comment(visit["id"], edited_comment)
                st.session_state[state_key] = False
                st.rerun()
            except Exception as error:
                st.error(f"Ошибка сохранения комментария: {error}")

    with col_cancel:
        if st.button(
            "✖ Отмена",
            key=f"cancel_edit_{visit['id']}",
            use_container_width=True,
        ):
            st.session_state[state_key] = False
            st.rerun()


def show_worker_dashboard(df, worker, logout):
    col_title, col_logout = st.columns([4, 1])
    with col_title:
        st.title("📍 Маршруты")
        st.caption(f"👤 Мерчендайзер: {worker}")
    with col_logout:
        st.write("")
        if st.button("🚪 Выйти", use_container_width=True):
            logout()

    worker_data = get_worker_data(df, worker)
    filters = _render_route_filters(worker_data)
    if filters is None:
        return

    day, selected_date, (day_data, routes) = filters
    selected_date_string = selected_date.isoformat()

    try:
        visits = get_completed_visits(selected_date_string, worker)
    except Exception as error:
        st.error(f"Ошибка загрузки прохождений: {error}")
        visits = []

    completed_visits = {
        get_point_key(
            visit["worker"], visit["weekday"], visit["route"], visit["shop"], visit["address"]
        ): visit
        for visit in visits
    }

    st.divider()
    st.subheader(f"👤 {worker}")
    st.write(f"📅 **{day}, {selected_date:%d.%m.%Y}**")
    st.write(f"Маршрутов: **{len(routes)}**")
    st.write(f"Всего ТТ: **{len(day_data)}**")

    for route in routes:
        route_data = day_data[day_data["Маршрут"] == route]
        total_points = len(route_data)
        completed_count = sum(
            get_point_key(worker, day, route, point["Магазин"], point["Адрес"]) in completed_visits
            for _, point in route_data.iterrows()
        )

        st.divider()
        st.subheader(f"🚗 {route}")
        st.progress(completed_count / total_points if total_points else 0)

        col1, col2, col3 = st.columns(3)
        col1.metric("Пройдено", completed_count)
        col2.metric("Осталось", total_points - completed_count)
        col3.metric("Всего", total_points)

        for number, (_, point) in enumerate(route_data.iterrows(), start=1):
            shop = point["Магазин"]
            address = point["Адрес"]
            point_key = get_point_key(worker, day, route, shop, address)
            visit = completed_visits.get(point_key)

            status = "🟢" if visit else "🔴"
            status_text = "Пройдена" if visit else "Не пройдена"

            with st.expander(
                f"{status} {number}. {shop} — {address} ({status_text})"
            ):
                st.write(f"🏪 **Магазин:** {shop}")
                st.write(f"📍 **Адрес:** {address}")

                if visit is None:
                    _render_new_visit(
                        point_key, selected_date, worker, day, route, shop, address
                    )
                else:
                    st.success("🟢 ТТ пройдена")
                    _render_photo_section(visit)
                    _render_comment_section(visit)
