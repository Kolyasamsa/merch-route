import streamlit as st


def apply_global_styles():
    st.markdown(
        """
        <style>
        .stMainBlockContainer {
            max-width: 980px;
            padding-top: 2rem;
            padding-bottom: 3rem;
        }

        div[data-testid="stExpander"] {
            border: 1px solid rgba(128, 128, 128, 0.22);
            border-radius: 16px;
            margin-bottom: 12px;
            overflow: hidden;
        }

        div[data-testid="stExpander"] details summary {
            padding: 0.85rem 1rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
