import streamlit as st


@st.dialog("📷 Фотография", width="large")
def show_photo_dialog(photo_url):
    st.image(photo_url, use_container_width=True)


def render_photo_grid(photos, key_prefix="photo"):
    """Показывает фотографии: 3 в ряд на ПК и 1 в колонку на телефоне."""
    if not photos:
        return

    columns = st.columns(3)
    for index, photo in enumerate(photos):
        with columns[index % 3]:
            st.image(photo["public_url"], use_container_width=True)
            if st.button(
                "🔍 Увеличить",
                key=f"{key_prefix}_open_{index}",
                use_container_width=True,
            ):
                show_photo_dialog(photo["public_url"])
