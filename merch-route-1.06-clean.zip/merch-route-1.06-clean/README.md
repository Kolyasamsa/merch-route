# Merch Route

Streamlit-приложение для мерчендайзеров и супервайзеров.

## Структура

- `streamlit_app.py` — точка входа.
- `ui/` — интерфейс и отдельные экраны.
- `database/` — работа с Supabase.
- `auth.py` — авторизация.
- `routes.py` — загрузка и обработка маршрутов.
- `utils.py` — общие функции и константы.
- `config.py` — подключение к Supabase и настройки.
- `routes.xlsx` — маршруты.

## Запуск

```bash
streamlit run streamlit_app.py
```
