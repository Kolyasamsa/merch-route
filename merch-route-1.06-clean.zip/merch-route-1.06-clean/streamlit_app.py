import streamlit as st

from auth import login, logout
from routes import load_routes
from ui.styles import apply_global_styles
from ui.supervisor_dashboard import show_supervisor_dashboard
from ui.worker_dashboard import show_worker_dashboard


st.set_page_config(
    page_title="Маршруты мерчендайзеров",
    page_icon="📍",
    layout="centered",
)

apply_global_styles()

user_name, user_role = login()
if not user_name:
    st.stop()

try:
    df = load_routes()
except Exception as error:
    st.error(f"Ошибка загрузки маршрутов: {error}")
    st.stop()

if user_role == "supervisor":
    show_supervisor_dashboard(df, user_name, logout)
    st.stop()

worker = user_name
if worker not in df["Мерчендайзер"].unique():
    st.error(f"Для мерчендайзера '{worker}' не найдены маршруты.")
    if st.button("🚪 Выйти"):
        logout()
    st.stop()

show_worker_dashboard(df, worker, logout)
